import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

export interface Preset {
  id: string;
  label: string;
  hint: string;
  make: () => RegExp;
}

export const PRESETS: Preset[] = [
  {
    id: "email",
    label: "Emails",
    hint: "name@domain.tld",
    make: () => /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,
  },
  {
    id: "phone",
    label: "Phones",
    hint: "(555) 013-4477",
    make: () =>
      /(?:\+\d{1,3}[\s.-]?)?(?:\(\d{3}\)|\d{3})[\s.-]\d{3}[\s.-]?\d{4}\b/g,
  },
  {
    id: "ssn",
    label: "SSN / IDs",
    hint: "000-00-0000",
    make: () => /\b\d{3}-\d{2}-\d{4}\b/g,
  },
  {
    id: "card",
    label: "Cards",
    hint: "0000 0000 0000 0000",
    make: () => /\b(?:\d{4}[\s-]?){3}\d{4}\b/g,
  },
];

export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function termPatterns(terms: string[]): { id: string; label: string; make: () => RegExp }[] {
  return terms
    .map((t) => t.trim())
    .filter((t) => t.length > 0)
    .map((t) => ({
      id: "term:" + t.toLowerCase(),
      label: "Term",
      make: () => new RegExp(escapeRegExp(t), "gi"),
    }));
}

export function compileCustom(src: string): RegExp | null {
  try {
    return new RegExp(src, "gi");
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Sample dossier — generated locally so the tool is testable with no  */
/* file at hand. Pure pdf-lib, never touches the network.              */
/* ------------------------------------------------------------------ */

export async function makeSamplePdf(): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);

  const people = [
    {
      name: "Marianne K. Ellsworth",
      ssn: "524-68-1139",
      email: "m.ellsworth@acme-holdings.com",
      phone: "(415) 555-0182",
      card: "4539 1488 0343 6467",
      addr: "1847 Pacific Heights Blvd, San Francisco, CA",
    },
    {
      name: "Tobias R. Finch",
      ssn: "618-44-9027",
      email: "tobias.finch@acme-holdings.com",
      phone: "(628) 555-0117",
      card: "5412 7534 9921 0046",
      addr: "92 Cedar Row, Apt 4B, Oakland, CA",
    },
    {
      name: "Priya N. Raghavan",
      ssn: "092-71-5563",
      email: "p.raghavan@acme-holdings.com",
      phone: "(510) 555-0244",
      card: "4916 2208 7731 5590",
      addr: "4001 Lakeshore Ter, Berkeley, CA",
    },
  ];

  const W = 612;
  const H = 792;

  const bodyLines = (p: (typeof people)[number], idx: number): string[] => [
    `Subject ${idx + 1}: ${p.name} is covered by the severance schedule in`,
    `Exhibit C. Direct questions to ${p.email} or by phone at ${p.phone}.`,
    ``,
    `National ID on file: ${p.ssn}. Reimbursement will be issued to the`,
    `corporate card ending in the account ${p.card}, per the finance`,
    `memo dated March 3. The cardholder address of record is`,
    `${p.addr}.`,
    ``,
    `All parties agree that the identifiers above are confidential and`,
    `must be removed from any copy shared outside the review room.`,
  ];

  for (let pi = 0; pi < 3; pi++) {
    const page = doc.addPage([W, H]);
    const p = people[pi];

    // letterhead
    page.drawText("ACME HOLDINGS — INTERNAL", { x: 54, y: H - 64, size: 9, font: bold, color: rgb(0.6, 0.2, 0.1) });
    page.drawLine({ start: { x: 54, y: H - 74 }, end: { x: W - 54, y: H - 74 }, thickness: 1.5, color: rgb(0.09, 0.07, 0.05) });
    page.drawText("CONFIDENTIAL OFFBOARDING MEMO", { x: 54, y: H - 106, size: 21, font: bold, color: rgb(0.09, 0.07, 0.05) });
    page.drawText(`Page ${pi + 1} of 3  ·  Case file ${2400 + pi * 7}  ·  Do not distribute`, {
      x: 54,
      y: H - 126,
      size: 9,
      font,
      color: rgb(0.45, 0.42, 0.38),
    });

    let y = H - 168;
    const write = (line: string, f = font, size = 11) => {
      page.drawText(line, { x: 54, y, size, font: f, color: rgb(0.12, 0.1, 0.08) });
      y -= size + 8;
    };

    write(`PERSONNEL RECORD — ${p.name.toUpperCase()}`, bold, 12);
    y -= 6;
    for (const line of bodyLines(p, pi)) write(line || " ");

    y -= 10;
    write("SEPARATION TERMS", bold, 12);
    y -= 4;
    write(
      "The departing employee retains vesting rights described in section 4.2."
    );
    write(
      `Contact ${p.email} within 30 days to elect COBRA continuation.`
    );
    write(
      `Final direct deposit confirmation was sent to ${p.phone}.`
    );

    y -= 26;
    write("Approved by:", bold, 10);
    // a faux signature scrawl worth drawing a manual box over
    page.drawText("H. J. Whitcombe", {
      x: 60,
      y: y - 22,
      size: 20,
      font: await doc.embedFont(StandardFonts.HelveticaOblique),
      color: rgb(0.1, 0.12, 0.35),
    });
    page.drawLine({ start: { x: 56, y: y - 28 }, end: { x: 240, y: y - 28 }, thickness: 0.8, color: rgb(0.3, 0.3, 0.3) });
    page.drawText("Head of People Operations", { x: 56, y: y - 42, size: 8.5, font, color: rgb(0.45, 0.42, 0.38) });

    page.drawText("BLACKOUT SAMPLE · GENERATED IN YOUR BROWSER", {
      x: 54,
      y: 46,
      size: 7.5,
      font,
      color: rgb(0.55, 0.52, 0.47),
    });
  }

  return doc.save();
}
