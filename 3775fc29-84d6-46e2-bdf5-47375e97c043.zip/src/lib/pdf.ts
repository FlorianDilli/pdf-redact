import * as pdfjs from "pdfjs-dist";
import type { PDFDocumentProxy } from "pdfjs-dist";
import PdfWorker from "pdfjs-dist/build/pdf.worker.min.mjs?worker&inline";
import { PDFDocument } from "pdf-lib";

if (!pdfjs.GlobalWorkerOptions.workerPort) {
  pdfjs.GlobalWorkerOptions.workerPort = new PdfWorker();
}

/* ----------------------------- types ----------------------------- */

export interface PageDim {
  w: number;
  h: number;
}

export interface PdfDoc {
  id: string;
  name: string;
  size: number;
  proxy: PDFDocumentProxy;
  numPages: number;
  dims: PageDim[];
}

/** Rectangle in PDF user units, origin top-left. */
export interface Rect {
  pageIndex: number;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Box extends Rect {
  id: string;
}

export interface Match extends Box {
  text: string;
  context: string;
  source: string;
  enabled: boolean;
}

export interface ScanPattern {
  id: string;
  label: string;
  regex: RegExp;
}

interface TItem {
  str: string;
  transform: number[];
  width: number;
  height: number;
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
}

/* ----------------------------- open ------------------------------ */

export async function openPdf(data: Uint8Array, name: string, size: number): Promise<PdfDoc> {
  const proxy = await pdfjs.getDocument({ data: data.slice() }).promise;
  const dims: PageDim[] = [];
  for (let i = 1; i <= proxy.numPages; i++) {
    const page = await proxy.getPage(i);
    const v = page.getViewport({ scale: 1 });
    dims.push({ w: v.width, h: v.height });
  }
  return { id: uid(), name, size, proxy, numPages: proxy.numPages, dims };
}

/* ----------------------------- scan ------------------------------ */

export async function scanDocument(
  doc: PdfDoc,
  patterns: ScanPattern[],
  onProgress: (frac: number) => void
): Promise<Match[]> {
  const out: Match[] = [];
  const seen = new Set<string>();

  for (let pi = 0; pi < doc.numPages; pi++) {
    const page = await doc.proxy.getPage(pi + 1);
    const tc = await page.getTextContent();
    const dim = doc.dims[pi];

    const items = (tc.items as unknown as TItem[]).filter((i) => i.str && i.str.trim().length > 0);
    // group into visual lines by baseline y
    items.sort((a, b) => b.transform[5] - a.transform[5] || a.transform[4] - b.transform[4]);
    const lines: TItem[][] = [];
    for (const it of items) {
      const h = Math.abs(it.transform[3]) || it.height || 10;
      const last = lines[lines.length - 1];
      if (last && Math.abs(last[0].transform[5] - it.transform[5]) <= Math.max(2, h * 0.55)) {
        last.push(it);
      } else {
        lines.push([it]);
      }
    }

    for (const line of lines) {
      line.sort((a, b) => a.transform[4] - b.transform[4]);
      let text = "";
      const segs: { it: TItem; s: number; e: number }[] = [];
      let prevEndX: number | null = null;
      for (const it of line) {
        const h = Math.abs(it.transform[3]) || 10;
        if (prevEndX !== null && it.transform[4] - prevEndX > h * 0.22) text += " ";
        const s = text.length;
        text += it.str;
        segs.push({ it, s, e: text.length });
        prevEndX = it.transform[4] + (it.width || 0);
      }

      for (const pat of patterns) {
        const re = pat.regex;
        re.lastIndex = 0;
        let m: RegExpExecArray | null;
        while ((m = re.exec(text))) {
          if (m[0].length === 0) {
            re.lastIndex++;
            continue;
          }
          const s = m.index;
          const e = m.index + m[0].length;
          const covered = segs.filter((g) => g.e > s && g.s < e);
          if (covered.length === 0) continue;

          const first = covered[0];
          const lastSeg = covered[covered.length - 1];
          const fLen = first.it.str.length || 1;
          const lLen = lastSeg.it.str.length || 1;
          const fFrac = Math.max(0, s - first.s) / fLen;
          const lFrac = Math.min(lLen, e - lastSeg.s) / lLen;
          const x0 = first.it.transform[4] + fFrac * (first.it.width || 0);
          const x1 = lastSeg.it.transform[4] + lFrac * (lastSeg.it.width || 0);
          const baseY = first.it.transform[5];
          const h = Math.abs(first.it.transform[3]) || 10;
          const padX = h * 0.08;

          const rect: Rect = {
            pageIndex: pi,
            x: Math.max(0, x0 - padX),
            y: Math.max(0, dim.h - (baseY + h * 0.82)),
            w: Math.max(2, x1 - x0 + padX * 2),
            h: h * 1.1,
          };

          const key = `${pi}|${Math.round(rect.x)}|${Math.round(rect.y)}|${m[0].toLowerCase()}`;
          if (seen.has(key)) continue;
          seen.add(key);

          const cs = Math.max(0, s - 30);
          const ce = Math.min(text.length, e + 30);
          out.push({
            id: uid(),
            ...rect,
            text: m[0],
            context:
              (cs > 0 ? "…" : "") + text.slice(cs, ce).replace(/\s+/g, " ") + (ce < text.length ? "…" : ""),
            source: pat.id,
            enabled: true,
          });
          if (out.length >= 4000) return out;
        }
      }
    }
    onProgress((pi + 1) / doc.numPages);
  }
  return out;
}

/* ---------------------------- render ----------------------------- */

export async function renderPage(
  doc: PdfDoc,
  pageIndex: number,
  scale: number,
  canvas: HTMLCanvasElement
): Promise<{ cssW: number; cssH: number }> {
  const page = await doc.proxy.getPage(pageIndex + 1);
  const viewport = page.getViewport({ scale });
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  canvas.width = Math.floor(viewport.width * dpr);
  canvas.height = Math.floor(viewport.height * dpr);
  canvas.style.width = `${viewport.width}px`;
  canvas.style.height = `${viewport.height}px`;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("no 2d context");
  const transform = dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined;
  await page.render({ canvas, canvasContext: ctx, transform, viewport }).promise;
  return { cssW: viewport.width, cssH: viewport.height };
}

/* ---------------------------- export ----------------------------- */

export async function exportRedacted(
  doc: PdfDoc,
  rects: Rect[],
  fill: string,
  onProgress: (frac: number) => void
): Promise<Blob> {
  const out = await PDFDocument.create();
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("no 2d context");

  for (let i = 0; i < doc.numPages; i++) {
    const page = await doc.proxy.getPage(i + 1);
    const viewport = page.getViewport({ scale: 2 });
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvas, canvasContext: ctx, viewport }).promise;

    ctx.fillStyle = fill;
    for (const r of rects) {
      if (r.pageIndex !== i) continue;
      ctx.fillRect(r.x * 2, r.y * 2, r.w * 2, r.h * 2);
    }

    const png = canvas.toDataURL("image/png");
    const img = await out.embedPng(png);
    const p = out.addPage([doc.dims[i].w, doc.dims[i].h]);
    p.drawImage(img, { x: 0, y: 0, width: doc.dims[i].w, height: doc.dims[i].h });
    onProgress((i + 1) / doc.numPages);
    await new Promise((r) => setTimeout(r, 0));
  }

  const bytes = await out.save();
  return new Blob([bytes.slice().buffer as ArrayBuffer], { type: "application/pdf" });
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function outName(name: string): string {
  return name.replace(/\.pdf$/i, "") + "-REDACTED.pdf";
}
