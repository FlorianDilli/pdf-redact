import { useCallback, useState } from "react";
import { Loader2, Check, AlertTriangle, Info } from "lucide-react";
import Landing from "./components/Landing";
import Workspace from "./components/Workspace";
import { openPdf, type PdfDoc } from "./lib/pdf";
import { makeSamplePdf } from "./lib/presets";

interface Toast {
  id: number;
  kind: "ok" | "err" | "info";
  msg: string;
}

export default function App() {
  const [docs, setDocs] = useState<PdfDoc[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((kind: Toast["kind"], msg: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, kind, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);

  const ingest = useCallback(
    async (files: File[]) => {
      const pdfs = files.filter((f) => f.type === "application/pdf" || /\.pdf$/i.test(f.name));
      if (pdfs.length === 0) {
        toast("err", "That's not a PDF — drop a .pdf file");
        return;
      }
      const added: PdfDoc[] = [];
      for (const f of pdfs) {
        setBusy(`Reading ${f.name}…`);
        try {
          const data = new Uint8Array(await f.arrayBuffer());
          const d = await openPdf(data, f.name, f.size);
          added.push(d);
        } catch {
          toast("err", `Couldn't open ${f.name} — is it password-protected?`);
        }
      }
      setBusy(null);
      if (added.length) {
        setDocs((ds) => [...ds, ...added]);
        setActiveId(added[0].id);
        toast("ok", `${added.length} document${added.length === 1 ? "" : "s"} on the desk`);
      }
    },
    [toast]
  );

  const sample = useCallback(async () => {
    setBusy("Forging the sample dossier…");
    try {
      const bytes = await makeSamplePdf();
      const d = await openPdf(bytes, "sample-dossier.pdf", bytes.length);
      setDocs((ds) => [...ds, d]);
      setActiveId(d.id);
      toast("ok", "Sample dossier loaded — hit Scan");
    } catch {
      toast("err", "Couldn't build the sample");
    }
    setBusy(null);
  }, [toast]);

  const doc = docs.find((d) => d.id === activeId) ?? null;

  return (
    <div className="h-full">
      {doc ? (
        <Workspace docs={docs} doc={doc} onSwitchDoc={setActiveId} onNew={() => setActiveId(null)} toast={toast} />
      ) : (
        <Landing onFiles={ingest} onSample={sample} />
      )}

      {busy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-paper/85 backdrop-blur-sm">
          <div className="flex items-center gap-3 border-2 border-ink bg-bone px-5 py-4 shadow-block">
            <Loader2 size={20} className="animate-spin text-accent" />
            <span className="max-w-[60vw] truncate font-mono text-[12px] uppercase tracking-widest">{busy}</span>
          </div>
        </div>
      )}

      <div className="pointer-events-none fixed bottom-4 left-4 z-50 flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`flex max-w-xs animate-toast-in items-start gap-2.5 border-2 border-ink bg-ink px-3.5 py-2.5 text-paper shadow-block-sm ${
              t.kind === "ok" ? "border-l-[6px] border-l-accent" : t.kind === "err" ? "border-l-[6px] border-l-red-500" : "border-l-[6px] border-l-paper/50"
            }`}
          >
            {t.kind === "ok" ? (
              <Check size={15} className="mt-0.5 shrink-0 text-accent" />
            ) : t.kind === "err" ? (
              <AlertTriangle size={15} className="mt-0.5 shrink-0 text-red-400" />
            ) : (
              <Info size={15} className="mt-0.5 shrink-0 text-paper/70" />
            )}
            <span className="font-mono text-[11px] uppercase leading-relaxed tracking-wider">{t.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
