import { useEffect, useRef, useState } from "react";
import type { Box, Match, PdfDoc, Rect } from "../lib/pdf";
import { renderPage } from "../lib/pdf";

export type Mode = "pan" | "draw" | "select";

interface Props {
  doc: PdfDoc;
  pageIndex: number;
  scale: number;
  offset: { x: number; y: number };
  mode: Mode;
  matches: Match[];
  boxes: Box[];
  selectedBoxId: string | null;
  flashId: string | null;
  fitSignal: number;
  onViewport: (v: { scale: number; offset: { x: number; y: number } }) => void;
  onCreateBox: (r: Rect) => void;
  onUpdateBox: (id: string, r: Rect) => void;
  onSelectBox: (id: string | null) => void;
}

type Gesture =
  | { type: "pan"; sx: number; sy: number; ox: number; oy: number }
  | { type: "pinch"; d0: number; mid0: { x: number; y: number }; scale0: number; off0: { x: number; y: number } }
  | { type: "draw"; x0: number; y0: number }
  | { type: "move"; id: string; sx: number; sy: number; r0: Rect }
  | { type: "resize"; id: string; corner: string; anchor: { x: number; y: number } };

const MIN = 0.25;
const MAX = 8;

export default function PdfCanvas(p: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef<Gesture | null>(null);
  const [pageCss, setPageCss] = useState({ w: 0, h: 0 });
  const [draft, setDraft] = useState<Rect | null>(null);
  const vpRef = useRef({ scale: p.scale, offset: p.offset });
  vpRef.current = { scale: p.scale, offset: p.offset };

  /* render page bitmap */
  useEffect(() => {
    let alive = true;
    const canvas = canvasRef.current;
    if (!canvas) return;
    renderPage(p.doc, p.pageIndex, p.scale, canvas)
      .then((d) => {
        if (alive) setPageCss({ w: d.cssW, h: d.cssH });
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [p.doc, p.pageIndex, p.scale]);

  /* fit to container */
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const dim = p.doc.dims[p.pageIndex];
    if (!dim) return;
    const cw = el.clientWidth;
    const ch = el.clientHeight;
    const s = Math.min(Math.max(Math.min((cw - 56) / dim.w, (ch - 56) / dim.h), MIN), 2.5);
    p.onViewport({ scale: s, offset: { x: (cw - dim.w * s) / 2, y: (ch - dim.h * s) / 2 } });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.doc.id, p.pageIndex, p.fitSignal]);

  /* wheel zoom (non-passive) */
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      const { scale, offset } = vpRef.current;
      const ns = Math.min(Math.max(scale * Math.exp(-e.deltaY * 0.0016), MIN), MAX);
      const k = ns / scale;
      p.onViewport({ scale: ns, offset: { x: cx - (cx - offset.x) * k, y: cy - (cy - offset.y) * k } });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.doc.id]);

  const toPage = (clientX: number, clientY: number) => {
    const el = containerRef.current!;
    const rect = el.getBoundingClientRect();
    const { scale, offset } = vpRef.current;
    return { x: (clientX - rect.left - offset.x) / scale, y: (clientY - rect.top - offset.y) / scale };
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const el = containerRef.current!;
    el.setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      const rect = el.getBoundingClientRect();
      gesture.current = {
        type: "pinch",
        d0: Math.hypot(a.x - b.x, a.y - b.y),
        mid0: { x: (a.x + b.x) / 2 - rect.left, y: (a.y + b.y) / 2 - rect.top },
        scale0: vpRef.current.scale,
        off0: vpRef.current.offset,
      };
      setDraft(null);
      return;
    }

    const pt = toPage(e.clientX, e.clientY);
    if (p.mode === "draw") {
      gesture.current = { type: "draw", x0: pt.x, y0: pt.y };
      setDraft({ pageIndex: p.pageIndex, x: pt.x, y: pt.y, w: 0, h: 0 });
    } else {
      gesture.current = { type: "pan", sx: e.clientX, sy: e.clientY, ox: vpRef.current.offset.x, oy: vpRef.current.offset.y };
      if (p.mode === "select") p.onSelectBox(null);
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const g = gesture.current;
    if (!g) return;

    if (g.type === "pinch" && pointers.current.size >= 2) {
      const [a, b] = [...pointers.current.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const ns = Math.min(Math.max(g.scale0 * (d / Math.max(1, g.d0)), MIN), MAX);
      const k = ns / g.scale0;
      p.onViewport({
        scale: ns,
        offset: { x: g.mid0.x - (g.mid0.x - g.off0.x) * k, y: g.mid0.y - (g.mid0.y - g.off0.y) * k },
      });
      return;
    }
    if (g.type === "pan") {
      p.onViewport({ scale: vpRef.current.scale, offset: { x: g.ox + e.clientX - g.sx, y: g.oy + e.clientY - g.sy } });
      return;
    }
    if (g.type === "draw") {
      const pt = toPage(e.clientX, e.clientY);
      setDraft({
        pageIndex: p.pageIndex,
        x: Math.min(g.x0, pt.x),
        y: Math.min(g.y0, pt.y),
        w: Math.abs(pt.x - g.x0),
        h: Math.abs(pt.y - g.y0),
      });
      return;
    }
    if (g.type === "move") {
      const pt = toPage(e.clientX, e.clientY);
      p.onUpdateBox(g.id, { ...g.r0, x: g.r0.x + (pt.x - g.sx), y: g.r0.y + (pt.y - g.sy) });
      return;
    }
    if (g.type === "resize") {
      const pt = toPage(e.clientX, e.clientY);
      const x = Math.min(g.anchor.x, pt.x);
      const y = Math.min(g.anchor.y, pt.y);
      p.onUpdateBox(g.id, {
        pageIndex: p.pageIndex,
        x,
        y,
        w: Math.max(6 / vpRef.current.scale, Math.abs(pt.x - g.anchor.x)),
        h: Math.max(6 / vpRef.current.scale, Math.abs(pt.y - g.anchor.y)),
      });
    }
  };

  const onPointerUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    const g = gesture.current;
    if (g?.type === "draw" && draft) {
      const minSize = 5 / vpRef.current.scale;
      if (draft.w > minSize && draft.h > minSize) p.onCreateBox(draft);
      setDraft(null);
    }
    if (pointers.current.size === 0) gesture.current = null;
    else if (pointers.current.size === 1 && g?.type === "pinch") {
      const [rest] = [...pointers.current.values()];
      gesture.current = { type: "pan", sx: rest.x, sy: rest.y, ox: vpRef.current.offset.x, oy: vpRef.current.offset.y };
    }
  };

  const startMove = (e: React.PointerEvent, b: Box) => {
    if (p.mode !== "select") return;
    e.stopPropagation();
    containerRef.current?.setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    p.onSelectBox(b.id);
    const pt = toPage(e.clientX, e.clientY);
    gesture.current = { type: "move", id: b.id, sx: pt.x, sy: pt.y, r0: { ...b } };
  };

  const startResize = (e: React.PointerEvent, b: Box, corner: string) => {
    e.stopPropagation();
    containerRef.current?.setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const anchor = {
      x: corner.includes("w") ? b.x + b.w : b.x,
      y: corner.includes("n") ? b.y + b.h : b.y,
    };
    gesture.current = { type: "resize", id: b.id, corner, anchor };
  };

  const cursor =
    p.mode === "draw" ? "cursor-crosshair" : p.mode === "pan" ? "cursor-grab active:cursor-grabbing" : "cursor-default";

  return (
    <div
      ref={containerRef}
      className={`relative h-full w-full touch-none select-none overflow-hidden bg-paper-2 ${cursor}`}
      style={{
        backgroundImage:
          "radial-gradient(rgba(23,19,12,0.09) 1px, transparent 1px)",
        backgroundSize: "22px 22px",
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
    >
      <div
        className="absolute left-0 top-0"
        style={{ transform: `translate(${p.offset.x}px, ${p.offset.y}px) scale(${p.scale})`, transformOrigin: "0 0" }}
      >
        <div className="relative bg-white shadow-[0_10px_40px_rgba(23,19,12,0.28)]" style={{ width: pageCss.w, height: pageCss.h }}>
          <canvas ref={canvasRef} className="block" />

          {/* match highlights */}
          {p.matches.map((m) => (
            <div
              key={m.id}
              className={`absolute ${m.enabled ? "border-[1.5px] border-accent bg-accent/15" : "border border-dashed border-ink/35 bg-ink/5"} ${
                p.flashId === m.id ? "animate-flash" : ""
              }`}
              style={{ left: m.x * p.scale, top: m.y * p.scale, width: m.w * p.scale, height: m.h * p.scale }}
            />
          ))}

          {/* manual boxes */}
          {p.boxes.map((b) => {
            const sel = b.id === p.selectedBoxId;
            return (
              <div
                key={b.id}
                onPointerDown={(e) => startMove(e, b)}
                className={`absolute ${p.mode === "select" ? "cursor-move" : "pointer-events-none"} ${
                  sel ? "outline outline-2 outline-offset-2 outline-accent" : ""
                } border border-ink bg-ink/85`}
                style={{ left: b.x * p.scale, top: b.y * p.scale, width: b.w * p.scale, height: b.h * p.scale }}
              >
                {sel &&
                  (["nw", "ne", "sw", "se"] as const).map((c) => (
                    <div
                      key={c}
                      onPointerDown={(e) => startResize(e, b, c)}
                      className={`absolute h-3.5 w-3.5 border-2 border-paper bg-accent ${
                        c === "nw" || c === "se" ? "cursor-nwse-resize" : "cursor-nesw-resize"
                      } ${c.includes("w") ? "-left-2" : "-right-2"} ${c.includes("n") ? "-top-2" : "-bottom-2"}`}
                    />
                  ))}
              </div>
            );
          })}

          {/* draft */}
          {draft && (
            <div
              className="absolute border-2 border-dashed border-accent bg-accent/25"
              style={{ left: draft.x * p.scale, top: draft.y * p.scale, width: draft.w * p.scale, height: draft.h * p.scale }}
            />
          )}
        </div>
      </div>

      {pageCss.w === 0 && (
        <div className="absolute inset-0 flex items-center justify-center font-mono text-xs uppercase tracking-widest text-muted">
          rendering page…
        </div>
      )}
    </div>
  );
}
