import { useRef, useState } from "react";
import {
  Upload,
  Lock,
  ShieldCheck,
  ArrowRight,
  ScanLine,
  PenLine,
  Flame,
  FileDown,
  Check,
  FileText,
} from "lucide-react";

interface Props {
  onFiles: (files: File[]) => void;
  onSample: () => void;
}

const PROCESS = [
  {
    n: "01",
    title: "LOAD THE DOCUMENT",
    body: "Drop a PDF in — or generate the sample dossier. It is parsed in this tab and never transmitted anywhere.",
    icon: FileText,
  },
  {
    n: "02",
    title: "FLAG WHAT MATTERS",
    body: "Type a name or an account number, or switch on detectors for emails, phones, SSNs and card numbers. Every hit comes back with its page and context.",
    icon: ScanLine,
  },
  {
    n: "03",
    title: "CROSS OUT BY HAND",
    body: "Toggle individual hits, then draw, drag and resize boxes over signatures, photos and anything a search can't find. Pinch to zoom on touch.",
    icon: PenLine,
  },
  {
    n: "04",
    title: "BURN & DOWNLOAD",
    body: "Export re-renders every page to a 2× image with your boxes baked in. The text layer is destroyed — there is nothing left to un-redact.",
    icon: Flame,
  },
];

const MARQUEE = ["REDACTED", "CLASSIFIED", "PRIVILEGED", "SEALED", "WITHHELD", "EXPUNGED"];

export default function Landing({ onFiles, onSample }: Props) {
  const [drag, setDrag] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const pick = (list: FileList | null) => {
    if (!list || list.length === 0) return;
    onFiles(Array.from(list));
  };

  return (
    <div className="min-h-full overflow-x-hidden">
      {/* top strip */}
      <header className="flex items-center justify-between border-b-2 border-ink px-5 py-4 sm:px-8">
        <div className="font-display text-2xl tracking-wide">
          BLACKOUT<span className="text-accent">.</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden font-mono text-[11px] uppercase tracking-widest text-muted sm:block">
            local-only pdf redaction
          </span>
          <span className="flex items-center gap-1.5 border-2 border-ink bg-bone px-2.5 py-1 font-mono text-[11px] font-bold uppercase tracking-wider">
            <Lock size={12} className="text-accent" /> no server
          </span>
        </div>
      </header>

      {/* hero */}
      <section className="relative mx-auto grid max-w-7xl gap-10 px-5 pb-16 pt-12 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-14 lg:pt-20">
        <div className="animate-rise">
          <p className="mb-5 font-mono text-[11px] uppercase tracking-[0.28em] text-accent">
            a privacy tool for paper trails
          </p>
          <h1 className="font-display uppercase leading-[0.88] tracking-tight">
            <span className="block text-[17vw] sm:text-[13vw] lg:text-[7.2rem]">Burn the</span>
            <span className="redact-wipe block text-[17vw] text-outline sm:text-[13vw] lg:text-[7.2rem]">
              sensitive
            </span>
            <span className="block text-[17vw] sm:text-[13vw] lg:text-[7.2rem]">
              bits<span className="text-accent">.</span>
            </span>
          </h1>
          <p className="mt-7 max-w-xl text-[15px] leading-relaxed text-ink-2">
            Blackout reads your PDF right here in the tab, finds the names, numbers and account
            details you flag, lets you cross out anything else by hand — signatures, photos, margin
            scribbles — then flattens every page into an image so the originals can't be copied
            back out.
          </p>
          <div className="mt-7 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[11px] uppercase tracking-widest text-muted">
            <span className="flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-accent" /> 0 bytes uploaded
            </span>
            <span>2× raster burn</span>
            <span>works offline once loaded</span>
          </div>
        </div>

        {/* dropzone */}
        <div className="relative animate-rise lg:pt-6" style={{ animationDelay: "120ms" }}>
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDrag(false);
              pick(e.dataTransfer.files);
            }}
            className={`relative border-2 border-ink bg-bone p-8 shadow-block transition-all duration-200 sm:p-10 ${
              drag ? "-translate-y-1 bg-accent/10 shadow-block-accent" : ""
            }`}
          >
            <div className="absolute -top-3 left-6 bg-ink px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-paper">
              intake
            </div>
            <div
              className={`mx-auto flex h-16 w-16 items-center justify-center rounded-full border-2 border-ink transition-colors ${
                drag ? "bg-accent text-paper" : "bg-accent/15 text-accent"
              }`}
            >
              <Upload size={26} />
            </div>
            <h2 className="mt-6 text-center font-display text-3xl uppercase leading-none tracking-tight">
              Drag a PDF
              <br />
              into this box
            </h2>
            <p className="mt-3 text-center font-mono text-[11px] uppercase tracking-widest text-muted">
              one file or many · stays on disk
            </p>
            <button
              onClick={() => inputRef.current?.click()}
              className="mt-7 w-full border-2 border-ink bg-ink py-3 font-display text-lg uppercase tracking-wider text-paper transition-all hover:-translate-y-0.5 hover:bg-accent hover:shadow-block-sm active:translate-y-0"
            >
              Browse files
            </button>
            <button
              onClick={onSample}
              className="group mt-3 flex w-full items-center justify-center gap-2 py-2 font-mono text-[12px] uppercase tracking-widest text-ink-2 transition-colors hover:text-accent"
            >
              no file handy? run the sample dossier
              <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
            </button>
            <input
              ref={inputRef}
              type="file"
              accept="application/pdf,.pdf"
              multiple
              className="hidden"
              onChange={(e) => {
                pick(e.target.files);
                e.target.value = "";
              }}
            />
          </div>

          {/* rotating stamp */}
          <div className="pointer-events-none absolute -right-4 -top-10 hidden h-28 w-28 sm:block lg:-right-8">
            <svg viewBox="0 0 100 100" className="h-full w-full animate-spin-slow">
              <defs>
                <path id="circ" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
              </defs>
              <circle cx="50" cy="50" r="49" className="fill-ink" />
              <text className="fill-paper font-mono" style={{ fontSize: "10.5px", letterSpacing: "2.2px" }}>
                <textPath href="#circ">100% CLIENT-SIDE · PRIVACY-FIRST ·</textPath>
              </text>
              <text x="50" y="56" textAnchor="middle" className="fill-accent" style={{ fontSize: "22px" }}>
                ✳
              </text>
            </svg>
          </div>
        </div>
      </section>

      {/* marquee */}
      <div className="overflow-hidden border-y-2 border-ink bg-ink py-3">
        <div className="flex w-max animate-marquee gap-8 whitespace-nowrap">
          {[...MARQUEE, ...MARQUEE, ...MARQUEE, ...MARQUEE].map((w, i) => (
            <span key={i} className="flex items-center gap-8 font-display text-xl uppercase tracking-wider text-paper">
              {w} <span className="text-accent">██</span>
            </span>
          ))}
        </div>
      </div>

      {/* process */}
      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:py-24">
        <div className="mb-10 flex items-end justify-between">
          <h2 className="font-display text-5xl uppercase leading-none tracking-tight sm:text-6xl">
            The process<span className="text-accent">.</span>
          </h2>
          <span className="hidden font-mono text-[11px] uppercase tracking-widest text-muted md:block">
            four steps · no account · no cloud
          </span>
        </div>
        <div className="border-t-2 border-ink">
          {PROCESS.map((p) => (
            <div
              key={p.n}
              className="group grid grid-cols-[auto_1fr_auto] items-center gap-5 border-b-2 border-ink px-2 py-6 transition-colors duration-200 hover:bg-ink hover:text-paper sm:gap-8 sm:px-5"
            >
              <span className="font-display text-4xl text-accent sm:text-6xl">{p.n}</span>
              <div>
                <h3 className="font-display text-2xl uppercase tracking-tight sm:text-3xl">{p.title}</h3>
                <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-ink-2 transition-colors group-hover:text-paper/75">
                  {p.body}
                </p>
              </div>
              <p.icon
                size={30}
                className="hidden text-muted transition-all duration-200 group-hover:translate-x-1 group-hover:text-accent sm:block"
              />
            </div>
          ))}
        </div>
      </section>

      {/* assurance band */}
      <section className="border-t-2 border-ink bg-ink text-paper">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-[1fr_auto] lg:items-center lg:py-24">
          <div>
            <h2 className="font-display text-5xl uppercase leading-[0.92] tracking-tight sm:text-7xl">
              The file never
              <br />
              leaves <span className="text-outline-paper">the room</span>
              <span className="text-accent">.</span>
            </h2>
            <ul className="mt-9 grid max-w-xl gap-3 sm:grid-cols-2">
              {[
                "Text hits with page number & context",
                "Hand-drawn boxes for signatures & photos",
                "Draw, move, resize, delete — mouse or touch",
                "Two-finger pinch zoom, smooth pan",
                "Per-hit on/off before you burn",
                "Single self-contained HTML file",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-sm text-paper/85">
                  <Check size={16} className="mt-0.5 shrink-0 text-accent" /> {t}
                </li>
              ))}
            </ul>
            <button
              onClick={() => inputRef.current?.click()}
              className="mt-10 inline-flex items-center gap-2.5 border-2 border-paper bg-accent px-7 py-3.5 font-display text-xl uppercase tracking-wider text-paper transition-all hover:-translate-y-0.5 hover:bg-accent-2"
            >
              <FileDown size={20} /> Start redacting
            </button>
            <input
              ref={inputRef}
              type="file"
              accept="application/pdf,.pdf"
              multiple
              className="hidden"
              onChange={(e) => {
                pick(e.target.files);
                e.target.value = "";
              }}
            />
          </div>

          {/* faux redacted page */}
          <div className="relative hidden w-72 animate-float lg:block">
            <div className="border-2 border-paper/30 bg-bone p-6 text-ink shadow-[10px_10px_0_0_rgba(210,73,28,0.9)]">
              <div className="h-2 w-24 bg-ink" />
              <div className="mt-1.5 h-2 w-16 bg-ink/70" />
              <div className="mt-5 space-y-2">
                <div className="h-1.5 w-full bg-ink/20" />
                <div className="h-1.5 w-11/12 bg-ink/20" />
                <div className="flex items-center gap-1.5">
                  <div className="h-1.5 w-14 bg-ink/20" />
                  <div className="h-3.5 w-28 bg-ink" />
                </div>
                <div className="h-1.5 w-full bg-ink/20" />
                <div className="flex items-center gap-1.5">
                  <div className="h-3.5 w-32 bg-ink" />
                  <div className="h-1.5 w-20 bg-ink/20" />
                </div>
                <div className="h-1.5 w-9/12 bg-ink/20" />
                <div className="h-1.5 w-full bg-ink/20" />
                <div className="relative h-6 w-36">
                  <div className="absolute inset-0 border-2 border-accent bg-accent/10" />
                  <span className="absolute -right-1 -top-2.5 bg-accent px-1 font-mono text-[8px] font-bold uppercase text-paper">
                    you draw this
                  </span>
                </div>
                <div className="h-1.5 w-10/12 bg-ink/20" />
                <div className="h-3.5 w-24 bg-ink" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="flex flex-wrap items-center justify-between gap-3 border-t-2 border-ink px-5 py-5 font-mono text-[11px] uppercase tracking-widest text-muted sm:px-8">
        <span>
          BLACKOUT<span className="text-accent">®</span> — built on pdf.js + pdf-lib
        </span>
        <span>single file · no install · no telemetry</span>
      </footer>
    </div>
  );
}
