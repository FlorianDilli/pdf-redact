import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Hand,
  SquareDashed,
  MousePointer2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Download,
  ChevronLeft,
  ChevronRight,
  Wrench,
  FileDown,
} from "lucide-react";
import PdfCanvas, { type Mode } from "./PdfCanvas";
import Sidebar from "./Sidebar";
import { PRESETS, termPatterns, compileCustom } from "../lib/presets";
import {
  type PdfDoc,
  type Match,
  type Box,
  type Rect,
  scanDocument,
  exportRedacted,
  downloadBlob,
  outName,
  uid,
} from "../lib/pdf";

interface WorkState {
  matches: Match[];
  boxes: Box[];
}

interface Props {
  docs: PdfDoc[];
  doc: PdfDoc;
  onSwitchDoc: (id: string) => void;
  onNew: () => void;
  toast: (kind: "ok" | "err" | "info", msg: string) => void;
}

export default function Workspace({ docs, doc, onSwitchDoc, onNew, toast }: Props) {
  const [work, setWork] = useState<Record<string, WorkState>>({});
  const cur = work[doc.id] ?? { matches: [], boxes: [] };

  const [page, setPage] = useState(0);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [mode, setMode] = useState<Mode>("select");
  const [selBox, setSelBox] = useState<string | null>(null);
  const [fitSignal, setFitSignal] = useState(0);

  const [terms, setTerms] = useState("");
  const [presetOn, setPresetOn] = useState<Set<string>>(() => new Set(["email"]));
  const [customRe, setCustomRe] = useState("");
  const [scanning, setScanning] = useState<number | null>(null);
  const [exp, setExp] = useState<number | null>(null);
  const [fill, setFill] = useState("#17130c");
  const [drawer, setDrawer] = useState(false);
  const [flashId, setFlashId] = useState<string | null>(null);

  /* reset view when switching docs */
  useEffect(() => {
    setPage(0);
    setSelBox(null);
    setFitSignal((s) => s + 1);
  }, [doc.id]);

  const setMatches = (fn: (m: Match[]) => Match[]) =>
    setWork((w) => ({ ...w, [doc.id]: { matches: fn((w[doc.id] ?? { matches: [], boxes: [] }).matches), boxes: (w[doc.id] ?? { matches: [], boxes: [] }).boxes } }));
  const setBoxes = (fn: (b: Box[]) => Box[]) =>
    setWork((w) => ({ ...w, [doc.id]: { matches: (w[doc.id] ?? { matches: [], boxes: [] }).matches, boxes: fn((w[doc.id] ?? { matches: [], boxes: [] }).boxes) } }));

  /* ------------------------------ scan ------------------------------ */
  const runScan = useCallback(async () => {
    if (scanning !== null) return;
    const patterns = [
      ...termPatterns(terms.split(/\n|,/)).map((t) => ({ id: t.id, label: t.label, regex: t.make() })),
      ...PRESETS.filter((p) => presetOn.has(p.id)).map((p) => ({ id: p.id, label: p.label, regex: p.make() })),
    ];
    if (customRe.trim()) {
      const re = compileCustom(customRe.trim());
      if (re) patterns.push({ id: "custom", label: "Regex", regex: re });
      else {
        toast("err", "Custom regex won't compile");
        return;
      }
    }
    if (patterns.length === 0) {
      toast("info", "Add a term or switch on a detector first");
      return;
    }
    setScanning(0);
    try {
      const found = await scanDocument(doc, patterns, (f) => setScanning(f));
      setWork((w) => ({ ...w, [doc.id]: { matches: found, boxes: (w[doc.id]?.boxes ?? []) } }));
      const pages = new Set(found.map((m) => m.pageIndex)).size;
      toast(found.length ? "ok" : "info", found.length ? `${found.length} matches across ${pages} page${pages === 1 ? "" : "s"}` : "No matches for those patterns");
      if (found.length) setPage(found[0].pageIndex);
    } catch {
      toast("err", "Scan failed — is this PDF password-protected?");
    } finally {
      setScanning(null);
    }
  }, [doc, terms, presetOn, customRe, scanning, toast]);

  /* ------------------------------ export ---------------------------- */
  const enabledRects: Rect[] = useMemo(
    () => [
      ...cur.matches.filter((m) => m.enabled).map(({ pageIndex, x, y, w, h }) => ({ pageIndex, x, y, w, h })),
      ...cur.boxes.map(({ pageIndex, x, y, w, h }) => ({ pageIndex, x, y, w, h })),
    ],
    [cur]
  );

  const runExport = useCallback(async () => {
    if (exp !== null) return;
    if (enabledRects.length === 0) {
      toast("info", "Nothing to burn — enable a match or draw a box");
      return;
    }
    setExp(0);
    try {
      const blob = await exportRedacted(doc, enabledRects, fill, (f) => setExp(f));
      downloadBlob(blob, outName(doc.name));
      toast("ok", `Burned ${enabledRects.length} region${enabledRects.length === 1 ? "" : "s"} into ${doc.numPages} page${doc.numPages === 1 ? "" : "s"}`);
    } catch {
      toast("err", "Export failed");
    } finally {
      setExp(null);
    }
  }, [doc, enabledRects, fill, exp, toast]);

  /* --------------------------- box editing -------------------------- */
  const createBox = (r: Rect) => {
    const b: Box = { id: uid(), ...r };
    setBoxes((bs) => [...bs, b]);
    setSelBox(b.id);
    setMode("select");
  };
  const updateBox = (id: string, r: Rect) => setBoxes((bs) => bs.map((b) => (b.id === id ? { ...b, ...r } : b)));
  const deleteBox = useCallback(() => {
    if (!selBox) return;
    setBoxes((bs) => bs.filter((b) => b.id !== selBox));
    setSelBox(null);
  }, [selBox]);

  /* ------------------------------ zoom ------------------------------ */
  const zoomBy = (f: number) => {
    const dim = doc.dims[page];
    const ns = Math.min(Math.max(scale * f, 0.25), 8);
    const cx = offset.x + (dim.w / 2) * scale;
    const cy = offset.y + (dim.h / 2) * scale;
    setScale(ns);
    setOffset({ x: cx - (dim.w / 2) * ns, y: cy - (dim.h / 2) * ns });
  };

  /* ---------------------------- keyboard ---------------------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT") return;
      if ((e.key === "Delete" || e.key === "Backspace") && selBox) {
        e.preventDefault();
        deleteBox();
      } else if (e.key === "Escape") {
        setSelBox(null);
        setDrawer(false);
      } else if (e.key === "v") setMode("select");
      else if (e.key === "h") setMode("pan");
      else if (e.key === "b") setMode("draw");
      else if (e.key === "ArrowRight") setPage((p) => Math.min(p + 1, doc.numPages - 1));
      else if (e.key === "ArrowLeft") setPage((p) => Math.max(p - 1, 0));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selBox, deleteBox, doc.numPages]);

  const jump = (m: Match) => {
    setPage(m.pageIndex);
    setFlashId(m.id);
    setDrawer(false);
    setTimeout(() => setFlashId(null), 1200);
  };

  const modeHint =
    mode === "draw"
      ? "drag on the page to box a region"
      : mode === "pan"
        ? "drag to pan · pinch or scroll to zoom"
        : "drag boxes to move · corners resize · del removes";

  const MODES: { id: Mode; icon: typeof Hand; key: string; label: string }[] = [
    { id: "select", icon: MousePointer2, key: "V", label: "Select" },
    { id: "draw", icon: SquareDashed, key: "B", label: "Draw" },
    { id: "pan", icon: Hand, key: "H", label: "Pan" },
  ];

  return (
    <div className="flex h-full flex-col">
      {/* top bar */}
      <header className="z-20 flex flex-wrap items-center gap-x-3 gap-y-2 border-b-2 border-ink bg-paper px-3 py-2 sm:px-4">
        <button onClick={onNew} className="font-display text-xl tracking-wide hover:text-accent" title="Back to start">
          BLACKOUT<span className="text-accent">.</span>
        </button>
        <span className="hidden h-6 w-0.5 bg-line sm:block" />
        <div className="flex min-w-0 items-center gap-2">
          <select
            value={doc.id}
            onChange={(e) => onSwitchDoc(e.target.value)}
            className="max-w-[38vw] truncate border-2 border-ink bg-bone px-2 py-1 font-mono text-[11px] uppercase tracking-wider outline-none focus:border-accent sm:max-w-[220px]"
          >
            {docs.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
          <span className="hidden font-mono text-[10px] uppercase tracking-widest text-muted md:block">
            {doc.numPages} pg
          </span>
        </div>

        <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
          {/* mode switch */}
          <div className="flex border-2 border-ink">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                title={`${m.label} (${m.key})`}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 transition-colors ${
                  mode === m.id ? "bg-ink text-paper" : "bg-bone hover:bg-paper-2"
                }`}
              >
                <m.icon size={15} className={mode === m.id ? "text-accent" : ""} />
                <span className="hidden font-mono text-[10px] uppercase tracking-widest xl:block">{m.label}</span>
              </button>
            ))}
          </div>

          {/* zoom */}
          <div className="hidden items-center border-2 border-ink bg-bone sm:flex">
            <button onClick={() => zoomBy(1 / 1.25)} className="p-1.5 hover:bg-paper-2" title="Zoom out">
              <ZoomOut size={15} />
            </button>
            <span className="w-12 text-center font-mono text-[11px]">{Math.round(scale * 100)}%</span>
            <button onClick={() => zoomBy(1.25)} className="p-1.5 hover:bg-paper-2" title="Zoom in">
              <ZoomIn size={15} />
            </button>
            <button
              onClick={() => setFitSignal((s) => s + 1)}
              className="border-l-2 border-ink p-1.5 hover:bg-paper-2"
              title="Fit page"
            >
              <Maximize2 size={15} />
            </button>
          </div>

          <button
            onClick={runExport}
            disabled={exp !== null}
            className="flex items-center gap-2 border-2 border-ink bg-accent px-3 py-1.5 font-display text-base uppercase tracking-wider text-paper transition-all hover:-translate-y-0.5 hover:bg-accent-2 hover:shadow-block-sm disabled:translate-y-0 disabled:opacity-60 sm:px-4"
          >
            <Download size={16} />
            <span className="hidden sm:inline">Export</span>
            {enabledRects.length > 0 && (
              <span className="bg-ink px-1.5 font-mono text-[10px]">{enabledRects.length}</span>
            )}
          </button>
        </div>
      </header>

      {/* body */}
      <div className="relative flex min-h-0 flex-1">
        <main className="relative min-w-0 flex-1">
          <PdfCanvas
            doc={doc}
            pageIndex={page}
            scale={scale}
            offset={offset}
            mode={mode}
            matches={cur.matches.filter((m) => m.pageIndex === page)}
            boxes={cur.boxes.filter((b) => b.pageIndex === page)}
            selectedBoxId={selBox}
            flashId={flashId}
            fitSignal={fitSignal}
            onViewport={(v) => {
              setScale(v.scale);
              setOffset(v.offset);
            }}
            onCreateBox={createBox}
            onUpdateBox={updateBox}
            onSelectBox={setSelBox}
          />

          {/* page nav */}
          <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 items-center border-2 border-ink bg-bone shadow-block-sm">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              className="p-2 hover:bg-paper-2 disabled:opacity-30"
              aria-label="Previous page"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="px-3 font-mono text-[12px] tracking-widest">
              {page + 1} / {doc.numPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(doc.numPages - 1, p + 1))}
              disabled={page === doc.numPages - 1}
              className="p-2 hover:bg-paper-2 disabled:opacity-30"
              aria-label="Next page"
            >
              <ChevronRight size={16} />
            </button>
          </div>

          {/* mode hint */}
          <div className="pointer-events-none absolute left-4 top-4 hidden items-center gap-2 border border-line bg-bone/90 px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-widest text-muted backdrop-blur-sm md:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
            {modeHint}
          </div>

          {/* mobile zoom */}
          <div className="absolute right-3 top-3 flex flex-col border-2 border-ink bg-bone shadow-block-sm sm:hidden">
            <button onClick={() => zoomBy(1.25)} className="p-2 hover:bg-paper-2" aria-label="Zoom in">
              <ZoomIn size={16} />
            </button>
            <button onClick={() => zoomBy(1 / 1.25)} className="border-t-2 border-ink p-2 hover:bg-paper-2" aria-label="Zoom out">
              <ZoomOut size={16} />
            </button>
            <button
              onClick={() => setFitSignal((s) => s + 1)}
              className="border-t-2 border-ink p-2 hover:bg-paper-2"
              aria-label="Fit"
            >
              <Maximize2 size={16} />
            </button>
          </div>

          {/* mobile toolkit FAB */}
          <button
            onClick={() => setDrawer(true)}
            className="absolute bottom-4 right-3 flex items-center gap-2 border-2 border-ink bg-ink px-3.5 py-2.5 font-display text-base uppercase tracking-wider text-paper shadow-block-accent transition-transform active:scale-95 lg:hidden"
          >
            <Wrench size={15} className="text-accent" />
            Toolkit
            {enabledRects.length > 0 && <span className="bg-accent px-1.5 font-mono text-[10px]">{enabledRects.length}</span>}
          </button>
        </main>

        {/* desktop sidebar */}
        <aside className="hidden w-[340px] shrink-0 border-l-2 border-ink lg:block">
          <Sidebar
            terms={terms}
            setTerms={setTerms}
            presetOn={presetOn}
            togglePreset={(id) =>
              setPresetOn((s) => {
                const n = new Set(s);
                if (n.has(id)) n.delete(id);
                else n.add(id);
                return n;
              })
            }
            customRe={customRe}
            setCustomRe={setCustomRe}
            onScan={runScan}
            scanning={scanning}
            matches={cur.matches}
            onToggleMatch={(id) => setMatches((ms) => ms.map((m) => (m.id === id ? { ...m, enabled: !m.enabled } : m)))}
            onSetAll={(on) => setMatches((ms) => ms.map((m) => ({ ...m, enabled: on })))}
            onJump={jump}
            boxCount={cur.boxes.length}
            fill={fill}
            setFill={setFill}
            hasSelectedBox={selBox !== null}
            onDeleteBox={deleteBox}
            onClose={() => setDrawer(false)}
          />
        </aside>

        {/* mobile drawer */}
        {drawer && (
          <div className="absolute inset-0 z-30 lg:hidden">
            <div className="absolute inset-0 bg-ink/50" onClick={() => setDrawer(false)} />
            <div className="absolute right-0 top-0 h-full w-[88%] max-w-sm border-l-2 border-ink shadow-2xl">
              <Sidebar
                terms={terms}
                setTerms={setTerms}
                presetOn={presetOn}
                togglePreset={(id) =>
                  setPresetOn((s) => {
                    const n = new Set(s);
                    if (n.has(id)) n.delete(id);
                    else n.add(id);
                    return n;
                  })
                }
                customRe={customRe}
                setCustomRe={setCustomRe}
                onScan={runScan}
                scanning={scanning}
                matches={cur.matches}
                onToggleMatch={(id) => setMatches((ms) => ms.map((m) => (m.id === id ? { ...m, enabled: !m.enabled } : m)))}
                onSetAll={(on) => setMatches((ms) => ms.map((m) => ({ ...m, enabled: on })))}
                onJump={jump}
                boxCount={cur.boxes.length}
                fill={fill}
                setFill={setFill}
                hasSelectedBox={selBox !== null}
                onDeleteBox={deleteBox}
                onClose={() => setDrawer(false)}
              />
            </div>
          </div>
        )}
      </div>

      {/* export overlay */}
      {exp !== null && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-ink/70 p-6">
          <div className="w-full max-w-xs border-2 border-ink bg-bone p-6 shadow-block">
            <div className="flex items-center gap-2.5">
              <FileDown size={20} className="text-accent" />
              <h3 className="font-display text-2xl uppercase tracking-wide">Burning</h3>
            </div>
            <p className="mt-1 font-mono text-[10.5px] uppercase tracking-widest text-muted">
              flattening page {Math.min(Math.ceil(exp * doc.numPages), doc.numPages)} of {doc.numPages}
            </p>
            <div className="mt-4 h-2.5 w-full border-2 border-ink bg-paper">
              <div className="h-full bg-accent transition-all duration-150" style={{ width: `${exp * 100}%` }} />
            </div>
            <p className="mt-3 font-mono text-[10px] leading-relaxed text-muted">
              rasterizing at 2× — the text layer will not survive this.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
