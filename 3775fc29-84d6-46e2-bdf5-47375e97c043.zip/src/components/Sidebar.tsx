import { ScanLine, Eye, EyeOff, X, Trash2, Loader2 } from "lucide-react";
import { PRESETS } from "../lib/presets";
import type { Match } from "../lib/pdf";

interface Props {
  terms: string;
  setTerms: (v: string) => void;
  presetOn: Set<string>;
  togglePreset: (id: string) => void;
  customRe: string;
  setCustomRe: (v: string) => void;
  onScan: () => void;
  scanning: number | null;
  matches: Match[];
  onToggleMatch: (id: string) => void;
  onSetAll: (on: boolean) => void;
  onJump: (m: Match) => void;
  boxCount: number;
  fill: string;
  setFill: (c: string) => void;
  hasSelectedBox: boolean;
  onDeleteBox: () => void;
  onClose: () => void;
}

function sourceLabel(src: string): string {
  if (src.startsWith("term:")) return "“" + src.slice(5).slice(0, 14) + "”";
  const p = PRESETS.find((x) => x.id === src);
  return p ? p.label : "regex";
}

function Snippet({ m }: { m: Match }) {
  const idx = m.context.toLowerCase().indexOf(m.text.toLowerCase());
  if (idx < 0) return <span>{m.context}</span>;
  return (
    <span>
      {m.context.slice(0, idx)}
      <mark className="hit">{m.context.slice(idx, idx + m.text.length)}</mark>
      {m.context.slice(idx + m.text.length)}
    </span>
  );
}

export default function Sidebar(p: Props) {
  const enabled = p.matches.filter((m) => m.enabled).length;
  const customValid = p.customRe.trim() === "" ? null : (() => {
    try {
      new RegExp(p.customRe);
      return true;
    } catch {
      return false;
    }
  })();

  return (
    <div className="flex h-full flex-col bg-bone">
      <div className="flex items-center justify-between border-b-2 border-ink px-4 py-3 lg:hidden">
        <span className="font-display text-lg uppercase tracking-wide">Toolkit</span>
        <button onClick={p.onClose} className="border-2 border-ink p-1.5 hover:bg-ink hover:text-paper" aria-label="Close panel">
          <X size={16} />
        </button>
      </div>

      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto">
        {/* FIND */}
        <section className="border-b border-line px-4 py-4">
          <div className="mb-3 flex items-baseline justify-between">
            <h3 className="font-display text-xl uppercase tracking-wide">
              <span className="mr-1.5 text-accent">01</span>Find
            </h3>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted">text + patterns</span>
          </div>
          <textarea
            value={p.terms}
            onChange={(e) => p.setTerms(e.target.value)}
            rows={2}
            placeholder={"one term per line\ne.g. Marianne  ·  524-68-1139"}
            className="w-full resize-none border-2 border-ink bg-paper px-3 py-2 font-mono text-[12px] leading-relaxed outline-none placeholder:text-muted/70 focus:border-accent"
          />
          <div className="mt-2.5 grid grid-cols-2 gap-2">
            {PRESETS.map((pr) => {
              const on = p.presetOn.has(pr.id);
              return (
                <button
                  key={pr.id}
                  onClick={() => p.togglePreset(pr.id)}
                  className={`border-2 border-ink px-2.5 py-1.5 text-left transition-all ${
                    on ? "bg-ink text-paper shadow-block-sm" : "bg-bone hover:-translate-y-0.5"
                  }`}
                >
                  <span className="block font-display text-sm uppercase tracking-wide">{pr.label}</span>
                  <span className={`block font-mono text-[9.5px] ${on ? "text-paper/60" : "text-muted"}`}>{pr.hint}</span>
                </button>
              );
            })}
          </div>

          <details className="mt-2.5 group">
            <summary className="cursor-pointer list-none font-mono text-[10px] uppercase tracking-widest text-muted hover:text-accent">
              + custom regex
            </summary>
            <div className="mt-2 flex items-center gap-2">
              <input
                value={p.customRe}
                onChange={(e) => p.setCustomRe(e.target.value)}
                placeholder="[A-Z]{2}\d{6}"
                className="w-full border-2 border-ink bg-paper px-2.5 py-1.5 font-mono text-[12px] outline-none focus:border-accent"
              />
              <span
                className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                  customValid === null ? "bg-muted/40" : customValid ? "bg-green-600" : "bg-accent"
                }`}
                title={customValid === false ? "invalid pattern" : ""}
              />
            </div>
          </details>

          <button
            onClick={p.onScan}
            disabled={p.scanning !== null}
            className="mt-3.5 flex w-full items-center justify-center gap-2 border-2 border-ink bg-accent py-2.5 font-display text-lg uppercase tracking-wider text-paper transition-all hover:-translate-y-0.5 hover:bg-accent-2 hover:shadow-block-sm disabled:translate-y-0 disabled:opacity-70"
          >
            {p.scanning !== null ? <Loader2 size={18} className="animate-spin" /> : <ScanLine size={18} />}
            {p.scanning !== null ? `Scanning ${Math.round(p.scanning * 100)}%` : "Scan document"}
          </button>
          {p.scanning !== null && (
            <div className="mt-2 h-1.5 w-full bg-ink/10">
              <div className="h-full bg-accent transition-all" style={{ width: `${p.scanning * 100}%` }} />
            </div>
          )}
        </section>

        {/* MATCHES */}
        <section className="border-b border-line px-4 py-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display text-xl uppercase tracking-wide">
              <span className="mr-1.5 text-accent">02</span>Matches
              <span className="ml-2 bg-ink px-1.5 py-0.5 font-mono text-[10px] text-paper">
                {enabled}/{p.matches.length}
              </span>
            </h3>
            {p.matches.length > 0 && (
              <div className="flex gap-1 font-mono text-[10px] uppercase tracking-widest">
                <button onClick={() => p.onSetAll(true)} className="border border-ink px-1.5 py-0.5 hover:bg-ink hover:text-paper">
                  all
                </button>
                <button onClick={() => p.onSetAll(false)} className="border border-ink px-1.5 py-0.5 hover:bg-ink hover:text-paper">
                  none
                </button>
              </div>
            )}
          </div>

          {p.matches.length === 0 ? (
            <div className="border-2 border-dashed border-ink/30 px-4 py-6 text-center">
              <p className="font-display text-base uppercase text-ink-2">No hits yet</p>
              <p className="mt-1 font-mono text-[10.5px] uppercase tracking-wider text-muted">
                add terms or presets above, then scan
              </p>
            </div>
          ) : (
            <ul className="space-y-1.5">
              {p.matches.map((m) => (
                <li key={m.id}>
                  <div
                    className={`group flex items-stretch border-2 transition-colors ${
                      m.enabled ? "border-ink bg-paper" : "border-line bg-paper/50"
                    }`}
                  >
                    <button onClick={() => p.onJump(m)} className="min-w-0 flex-1 px-2.5 py-2 text-left hover:bg-accent/10">
                      <div className="flex items-center gap-2">
                        <span className="shrink-0 bg-ink px-1 py-px font-mono text-[9px] font-bold text-paper">
                          P.{m.pageIndex + 1}
                        </span>
                        <span className="truncate font-mono text-[9px] uppercase tracking-wider text-accent">
                          {sourceLabel(m.source)}
                        </span>
                      </div>
                      <p
                        className={`mt-1 truncate font-mono text-[11px] ${m.enabled ? "text-ink-2" : "text-muted line-through"}`}
                      >
                        <Snippet m={m} />
                      </p>
                    </button>
                    <button
                      onClick={() => p.onToggleMatch(m.id)}
                      aria-label={m.enabled ? "Skip this match" : "Include this match"}
                      className={`flex w-9 shrink-0 items-center justify-center border-l-2 transition-colors ${
                        m.enabled ? "border-ink bg-ink text-paper hover:bg-accent" : "border-line text-muted hover:text-ink"
                      }`}
                    >
                      {m.enabled ? <Eye size={14} /> : <EyeOff size={14} />}
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* BURN */}
        <section className="px-4 py-4">
          <h3 className="mb-3 font-display text-xl uppercase tracking-wide">
            <span className="mr-1.5 text-accent">03</span>Burn
          </h3>
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted">box fill</span>
            <div className="flex gap-2">
              {[
                { c: "#17130c", label: "ink" },
                { c: "#fbf9f1", label: "paper" },
              ].map((s) => (
                <button
                  key={s.c}
                  onClick={() => p.setFill(s.c)}
                  title={s.label}
                  className={`h-7 w-7 border-2 transition-transform hover:-translate-y-0.5 ${
                    p.fill === s.c ? "border-accent ring-2 ring-accent/40" : "border-ink"
                  }`}
                  style={{ background: s.c }}
                />
              ))}
            </div>
          </div>

          <div className="mt-3 grid grid-cols-3 divide-x-2 divide-line border-2 border-ink bg-paper text-center">
            <div className="py-2">
              <div className="font-display text-xl">{enabled}</div>
              <div className="font-mono text-[9px] uppercase tracking-widest text-muted">hits</div>
            </div>
            <div className="py-2">
              <div className="font-display text-xl">{p.boxCount}</div>
              <div className="font-mono text-[9px] uppercase tracking-widest text-muted">boxes</div>
            </div>
            <div className="py-2">
              <div className="font-display text-xl text-accent">{enabled + p.boxCount}</div>
              <div className="font-mono text-[9px] uppercase tracking-widest text-muted">regions</div>
            </div>
          </div>

          {p.hasSelectedBox && (
            <button
              onClick={p.onDeleteBox}
              className="mt-3 flex w-full items-center justify-center gap-2 border-2 border-ink bg-paper py-2 font-mono text-[11px] uppercase tracking-widest transition-colors hover:bg-accent hover:text-paper"
            >
              <Trash2 size={13} /> delete selected box
            </button>
          )}

          <p className="mt-3 font-mono text-[10px] leading-relaxed text-muted">
            Export re-renders each page at 2× and burns every region into the pixels. The text layer
            underneath is destroyed — not hidden.
          </p>
        </section>
      </div>
    </div>
  );
}
